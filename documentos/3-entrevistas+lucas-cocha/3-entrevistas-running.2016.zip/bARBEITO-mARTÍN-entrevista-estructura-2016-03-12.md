# ENTREVISTA MARTIN BARBEITO / 2016

### PREGUNTAS GENERALES 

Sexo: Masculino

Edad: 39

Lugar donde vive: Córdoba capital

Profesión/Oficio: PROFESOR DE EDUCACIÓN FÍSICA

Tiempo que se desempeña en el sector del Running: 12 AÑOS.


### ÉL Y EL RUNNING

### EL TEAM
 
### FUNCION SOCIAL DEL RUNNING

### CRECIMIENTO DEL RUNNING 


### EL CUERPO DEL RUNNING

